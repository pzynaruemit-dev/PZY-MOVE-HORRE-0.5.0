package pzy.move.horre;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import pzy.move.horre.config.PzyConfig;
import pzy.move.horre.gui.PzyConfigScreen;
import pzy.move.horre.render.PzyHandState;

/** PZY MOVE HORRE client entrypoint. (c) PZY. All rights reserved. */
public final class PzyMoveHorreClient implements ClientModInitializer {
    private static final String CATEGORY = "key.categories.pzy_move_horre";

    @Override
    public void onInitializeClient() {
        PzyConfig.load();
        KeyBinding settings = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pzy_move_horre.open_settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            PzyHandState.tick(client);
            while (settings.wasPressed()) {
                if (client.player != null) client.setScreen(new PzyConfigScreen(client.currentScreen));
            }
        });
    }
}
