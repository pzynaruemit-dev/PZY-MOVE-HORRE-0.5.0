package pzy.move.horre.render;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;

/** Item groups that carry their own arm/item transform. (c) PZY. All rights reserved. */
public enum PzyKind {
    EMPTY("Empty hand"), SWORD("Sword"), AXE("Axe"), PICKAXE("Pickaxe"), SHOVEL("Shovel"), HOE("Hoe"),
    BLOCK("Block"), BOW("Bow"), CROSSBOW("Crossbow"), SHIELD("Shield"), TRIDENT("Trident"),
    FOOD("Food / drink"), ITEM("Other item");

    private final String label;

    PzyKind(String label) { this.label = label; }

    public String label() { return label; }

    public PzyKind next(int step) {
        PzyKind[] all = values();
        return all[Math.floorMod(ordinal() + step, all.length)];
    }

    public static PzyKind of(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return EMPTY;
        Item item = stack.getItem();
        if (item instanceof SwordItem) return SWORD;
        if (item instanceof AxeItem) return AXE;
        if (item instanceof PickaxeItem) return PICKAXE;
        if (item instanceof ShovelItem) return SHOVEL;
        if (item instanceof HoeItem) return HOE;
        if (item instanceof BowItem) return BOW;
        if (item instanceof CrossbowItem) return CROSSBOW;
        if (item instanceof ShieldItem) return SHIELD;
        if (item instanceof TridentItem) return TRIDENT;
        if (stack.contains(DataComponentTypes.FOOD)) return FOOD;
        if (item instanceof BlockItem) return BLOCK;
        return ITEM;
    }
}
