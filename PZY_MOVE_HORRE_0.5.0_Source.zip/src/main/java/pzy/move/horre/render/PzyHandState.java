package pzy.move.horre.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

/**
 * Client-tick state owned by PZY: which stack is shown in each hand, equip (hand-in / hand-out)
 * progress and view sway. Independent of vanilla's HeldItemRenderer state.
 * (c) PZY. All rights reserved.
 */
public final class PzyHandState {
    private PzyHandState() { }

    private static boolean ready;
    private static final ItemStack[] SHOWN = {ItemStack.EMPTY, ItemStack.EMPTY};
    private static final float[] UP = {1.0f, 1.0f};
    private static final float[] PREV_UP = {1.0f, 1.0f};
    private static float swayPitch, swayYaw, prevSwayPitch, prevSwayYaw;

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null) {
            ready = false;
            return;
        }
        if (!ready) {
            SHOWN[0] = player.getMainHandStack();
            SHOWN[1] = player.getOffHandStack();
            UP[0] = UP[1] = PREV_UP[0] = PREV_UP[1] = 1.0f;
            swayPitch = prevSwayPitch = player.getPitch();
            swayYaw = prevSwayYaw = player.getYaw();
            ready = true;
        }
        for (int i = 0; i < 2; i++) {
            ItemStack target = i == 0 ? player.getMainHandStack() : player.getOffHandStack();
            boolean same = SHOWN[i].getItem() == target.getItem();
            PREV_UP[i] = UP[i];
            float goal = same ? 1.0f : 0.0f;
            UP[i] += MathHelper.clamp(goal - UP[i], -0.4f, 0.4f);
            if (same || UP[i] < 0.1f) SHOWN[i] = target;
        }
        prevSwayPitch = swayPitch;
        prevSwayYaw = swayYaw;
        swayPitch += (player.getPitch() - swayPitch) * 0.5f;
        swayYaw += (player.getYaw() - swayYaw) * 0.5f;
    }

    public static ItemStack shown(boolean main) { return SHOWN[main ? 0 : 1]; }

    /** 0 = ready in hand, 1 = fully lowered. */
    public static float equip(boolean main, float tickDelta) {
        int i = main ? 0 : 1;
        return 1.0f - MathHelper.lerp(tickDelta, PREV_UP[i], UP[i]);
    }

    public static float swayPitch(float tickDelta) { return MathHelper.lerp(tickDelta, prevSwayPitch, swayPitch); }
    public static float swayYaw(float tickDelta) { return MathHelper.lerp(tickDelta, prevSwayYaw, swayYaw); }
}
