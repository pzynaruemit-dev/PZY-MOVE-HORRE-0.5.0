package pzy.move.horre.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import pzy.move.horre.config.PzyConfig;

/**
 * PZY first-person hand renderer. Replaces vanilla's first-person drawing completely:
 * PZY decides what is shown in each hand, where the arm and the item sit (per item kind,
 * from the settings sliders) and how they move.
 *
 * (c) PZY. All rights reserved. See PZY_LICENSE.txt.
 */
public final class PzyHandRenderer {
    private PzyHandRenderer() { }

    public static boolean shouldRender(AbstractClientPlayerEntity player) {
        if (player == null || !PzyConfig.isEnabled() || player.isSpectator() || player.isSleeping()) return false;
        if (player.getMainHandStack().isOf(Items.FILLED_MAP) || player.getOffHandStack().isOf(Items.FILLED_MAP)) return false;
        if (player.getMainHandStack().isOf(Items.SPYGLASS) || player.getOffHandStack().isOf(Items.SPYGLASS)) return false;
        return !(player.isUsingItem() && player.getActiveItem().isOf(Items.SPYGLASS));
    }

    public static void render(HeldItemRenderer held, MatrixStack m, VertexConsumerProvider.Immediate consumers,
                              ClientPlayerEntity player, float tickDelta, int light) {
        PlayerEntityRenderer renderer = playerRenderer(player);
        m.push();
        float sway = PzyConfig.sway();
        if (sway > 0.0f) {
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(
                    (player.getPitch(tickDelta) - PzyHandState.swayPitch(tickDelta)) * 0.1f * sway));
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(
                    (player.getYaw(tickDelta) - PzyHandState.swayYaw(tickDelta)) * 0.1f * sway));
        }
        Arm main = player.getMainArm();
        drawHand(held, m, consumers, renderer, player, main, true, tickDelta, light);
        drawHand(held, m, consumers, renderer, player, main.getOpposite(), false, tickDelta, light);
        m.pop();
        consumers.draw();
    }

    private static void drawHand(HeldItemRenderer held, MatrixStack m, VertexConsumerProvider consumers,
                                 PlayerEntityRenderer renderer, ClientPlayerEntity player, Arm arm,
                                 boolean isMain, float td, int light) {
        ItemStack stack = PzyHandState.shown(isMain);
        float equip = PzyHandState.equip(isMain, td);
        float swing = isMain ? clamp01(player.getHandSwingProgress(td)) : 0.0f;
        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;
        PzyKind kind = PzyKind.of(stack);
        boolean showArm = renderer != null && !player.isInvisible()
                && (isMain ? PzyConfig.isMainArmEnabled() : PzyConfig.isOffArmEnabled());
        float[] armPose = PzyConfig.pose(false, kind);
        float[] itemPose = PzyConfig.pose(true, kind);

        m.push();
        if (stack.isEmpty()) {
            if (showArm) {
                m.push();
                applyPose(m, armPose, side);
                drawArm(m, consumers, light, renderer, player, arm, swing, equip);
                m.pop();
            }
        } else {
            itemFrame(m, side, swing, equip);
            eatTransform(m, td, side, player, stack, isMain ? Hand.MAIN_HAND : Hand.OFF_HAND);
            if (showArm) {
                m.push();
                // Hand rest position relative to the item frame (vanilla: hand 0.64,-0.60 vs item 0.56,-0.52).
                m.translate(side * 0.08000005f, -0.08f, 0.0f);
                applyPose(m, armPose, side);
                drawArm(m, consumers, light, renderer, player, arm, 0.0f, 0.0f);
                m.pop();
            }
            m.push();
            applyPose(m, itemPose, side);
            held.renderItem(player, stack,
                    arm == Arm.RIGHT ? ModelTransformationMode.FIRST_PERSON_RIGHT_HAND
                            : ModelTransformationMode.FIRST_PERSON_LEFT_HAND,
                    arm == Arm.LEFT, m, consumers, light);
            m.pop();
        }
        m.pop();
    }

    /** Slider pose: x/y/z in pixels (1/16 block), rx/ry/rz in degrees. Mirrored for the left hand. */
    private static void applyPose(MatrixStack m, float[] p, float side) {
        if (p == null || p.length < 6) return;
        m.translate(side * p[0] / 16.0f, p[1] / 16.0f, p[2] / 16.0f);
        if (p[3] != 0.0f) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(p[3]));
        if (p[4] != 0.0f) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * p[4]));
        if (p[5] != 0.0f) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * p[5]));
    }

    /** Base item frame: swing arc, equip offset, swing rotation. */
    private static void itemFrame(MatrixStack m, float side, float swing, float equip) {
        float g = (float) Math.sqrt(swing);
        m.translate(side * -0.4f * (float) Math.sin(g * Math.PI),
                0.2f * (float) Math.sin(g * Math.PI * 2.0),
                -0.2f * (float) Math.sin(swing * Math.PI));
        m.translate(side * 0.56f, -0.52f + equip * -0.6f, -0.72f);
        float f = (float) Math.sin(swing * swing * Math.PI);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (45.0f + f * -20.0f)));
        float s = (float) Math.sin(g * Math.PI);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * s * -20.0f));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(s * -80.0f));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -45.0f));
    }

    private static void eatTransform(MatrixStack m, float td, float side, ClientPlayerEntity player,
                                     ItemStack stack, Hand hand) {
        if (!player.isUsingItem() || player.getActiveHand() != hand) return;
        String action = stack.getUseAction().name();
        if (!action.equals("EAT") && !action.equals("DRINK")) return;
        float left = player.getItemUseTimeLeft() - td + 1.0f;
        float total = player.getItemUseTimeLeft() + player.getItemUseTime();
        if (total <= 0.0f) return;
        float g = left / total;
        if (g < 0.8f) m.translate(0.0f, Math.abs((float) Math.cos(left / 4.0f * Math.PI) * 0.1f), 0.0f);
        float h = 1.0f - (float) Math.pow(Math.max(0.0f, g), 27.0);
        m.translate(h * 0.6f * side, h * -0.5f, 0.0f);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * h * 90.0f));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(h * 10.0f));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * h * 30.0f));
    }

    /** Vanilla empty-hand placement (the known-good arm orientation), then PlayerEntityRenderer draws the arm. */
    private static void drawArm(MatrixStack m, VertexConsumerProvider consumers, int light,
                                PlayerEntityRenderer renderer, AbstractClientPlayerEntity player,
                                Arm arm, float swingProgress, float equipProgress) {
        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;
        float swing = clamp01(swingProgress);
        float g = (float) Math.sqrt(swing);
        float h = -0.3f * (float) Math.sin(g * Math.PI);
        float i = 0.4f * (float) Math.sin(g * Math.PI * 2.0);
        float j = -0.4f * (float) Math.sin(swing * Math.PI);
        float k = (float) Math.sin(swing * swing * Math.PI);
        float l = (float) Math.sin(g * Math.PI);
        m.push();
        m.translate(side * (h + 0.64000005f), i - 0.6f + equipProgress * -0.6f, j - 0.71999997f);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 45.0f));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * l * 70.0f));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * k * -20.0f));
        m.translate(side * -1.0f, 3.6f, 3.5f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 120.0f));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(200.0f));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -135.0f));
        m.translate(side * 5.6f, 0.0f, 0.0f);
        if (arm == Arm.RIGHT) {
            renderer.renderRightArm(m, consumers, light, player);
        } else {
            renderer.renderLeftArm(m, consumers, light, player);
        }
        m.pop();
    }

    private static PlayerEntityRenderer playerRenderer(AbstractClientPlayerEntity player) {
        EntityRenderer<?> raw = MinecraftClient.getInstance().getEntityRenderDispatcher().getRenderer(player);
        return raw instanceof PlayerEntityRenderer renderer ? renderer : null;
    }

    private static float clamp01(float v) { return Math.max(0.0f, Math.min(1.0f, v)); }
}
