package pzy.move.horre.modmenu;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import pzy.move.horre.gui.PzyConfigScreen;

/** Optional Mod Menu integration. Mod Menu itself is not a required runtime dependency. */
public final class PzyModMenuApi implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return PzyConfigScreen::new;
    }
}
