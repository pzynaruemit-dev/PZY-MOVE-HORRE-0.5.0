package pzy.move.horre.mixin.client;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pzy.move.horre.render.PzyHandRenderer;

/**
 * PZY takes over first-person hand rendering completely (single hook).
 * (c) PZY. All rights reserved.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
            at = @At("HEAD"), cancellable = true)
    private void pzy$takeOver(float tickDelta, MatrixStack matrices,
                              VertexConsumerProvider.Immediate consumers,
                              ClientPlayerEntity player, int light, CallbackInfo ci) {
        if (!PzyHandRenderer.shouldRender(player)) return;
        PzyHandRenderer.render((HeldItemRenderer) (Object) this, matrices, consumers, player, tickDelta, light);
        ci.cancel();
    }
}
