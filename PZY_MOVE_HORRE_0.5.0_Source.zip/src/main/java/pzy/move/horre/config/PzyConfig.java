package pzy.move.horre.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import pzy.move.horre.render.PzyKind;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** PZY settings. Saved only when a value changes. (c) PZY. All rights reserved. */
public final class PzyConfig {
    private static final int VERSION = 3;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pzy_move_horre.json");
    private static Data data = new Data();

    private PzyConfig() { }

    public static void load() {
        if (!Files.isRegularFile(FILE)) {
            save();
            return;
        }
        try {
            Data loaded = GSON.fromJson(Files.readString(FILE), Data.class);
            if (loaded == null || loaded.configVersion < VERSION) {
                data = new Data(); // older layouts are not compatible with the v0.5 settings
                save();
                return;
            }
            data = loaded;
            sanitize();
        } catch (IOException | RuntimeException exception) {
            System.err.println("[PZY MOVE HORRE] Config read failed; using defaults: " + exception.getMessage());
            data = new Data();
        }
    }

    public static void save() {
        sanitize();
        data.configVersion = VERSION;
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(data));
        } catch (IOException exception) {
            System.err.println("[PZY MOVE HORRE] Config save failed: " + exception.getMessage());
        }
    }

    public static void resetAll() {
        data = new Data();
        save();
    }

    public static void resetKind(PzyKind kind) {
        data.arm.remove(kind.name());
        data.item.remove(kind.name());
        save();
    }

    private static void sanitize() {
        if (data == null) data = new Data();
        if (data.arm == null) data.arm = new HashMap<>();
        if (data.item == null) data.item = new HashMap<>();
        if (!Float.isFinite(data.sway)) data.sway = 1.0f;
        data.sway = Math.max(0.0f, Math.min(2.0f, data.sway));
        fix(data.arm);
        fix(data.item);
    }

    private static void fix(Map<String, float[]> map) {
        for (Map.Entry<String, float[]> e : map.entrySet()) {
            float[] v = e.getValue();
            float[] out = new float[6];
            if (v != null) {
                for (int i = 0; i < 6 && i < v.length; i++) out[i] = Float.isFinite(v[i]) ? v[i] : 0.0f;
            }
            e.setValue(out);
        }
    }

    /** Live pose array for one kind: {x, y, z (px), rx, ry, rz (deg)}. */
    public static float[] pose(boolean item, PzyKind kind) {
        Map<String, float[]> map = item ? data.item : data.arm;
        float[] v = map.get(kind.name());
        if (v == null || v.length < 6) {
            v = new float[6];
            map.put(kind.name(), v);
        }
        return v;
    }

    public static Data data() { return data; }
    public static boolean isEnabled() { return data.enabled; }
    public static boolean isMainArmEnabled() { return data.mainArm; }
    public static boolean isOffArmEnabled() { return data.offArm; }
    public static float sway() { return data.sway; }

    public static final class Data {
        public int configVersion = VERSION;
        public boolean enabled = true;
        public boolean mainArm = true;
        public boolean offArm = true;
        public float sway = 1.0f;
        public Map<String, float[]> arm = new HashMap<>();
        public Map<String, float[]> item = new HashMap<>();
    }
}
