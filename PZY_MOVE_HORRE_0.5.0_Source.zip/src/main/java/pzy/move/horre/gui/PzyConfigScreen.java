package pzy.move.horre.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import pzy.move.horre.config.PzyConfig;
import pzy.move.horre.render.PzyKind;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * PZY settings: a compact panel at the bottom of the screen so the hands stay visible while you
 * adjust them. Tabs: Main, Arm, Item, About.
 * (c) PZY. All rights reserved.
 */
public final class PzyConfigScreen extends Screen {
    private enum Tab { MAIN, ARM, ITEM, ABOUT }

    private static Tab tab = Tab.MAIN;
    private static PzyKind kind = PzyKind.EMPTY;

    private final Screen parent;
    private int panelX, panelY, panelW, panelH;

    public PzyConfigScreen(Screen parent) {
        super(Text.translatable("screen.pzy_move_horre.title"));
        this.parent = parent;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) kind = PzyKind.of(mc.player.getMainHandStack());
    }

    @Override
    protected void init() {
        panelW = Math.min(380, width - 12);
        panelH = switch (tab) {
            case MAIN -> 118;
            case ARM, ITEM -> 142;
            case ABOUT -> 104;
        };
        panelX = (width - panelW) / 2;
        panelY = Math.max(4, height - panelH - 6);

        int tabW = (panelW - 16 - 3 * 4) / 4;
        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            Tab t = tabs[i];
            Text label = Text.translatable("screen.pzy_move_horre.tab." + t.name().toLowerCase());
            ButtonWidget b = ButtonWidget.builder(t == tab ? Text.literal("> ").append(label) : label, button -> {
                tab = t;
                clearChildren();
                init();
            }).dimensions(panelX + 8 + i * (tabW + 4), panelY + 6, tabW, 18).build();
            addDrawableChild(b);
        }

        int cy = panelY + 30;
        switch (tab) {
            case MAIN -> initMain(cy);
            case ARM -> initPose(cy, false);
            case ITEM -> initPose(cy, true);
            case ABOUT -> addDrawableChild(ButtonWidget.builder(Text.translatable("screen.pzy_move_horre.close"),
                    button -> close()).dimensions(panelX + 8, panelY + panelH - 26, panelW - 16, 20).build());
        }
    }

    private void initMain(int cy) {
        int colW = (panelW - 20) / 2;
        int left = panelX + 8;
        int right = left + colW + 4;
        addToggle(left, cy, colW, "screen.pzy_move_horre.enabled",
                () -> PzyConfig.data().enabled, v -> PzyConfig.data().enabled = v);
        addDrawableChild(new PzySlider(right, cy, colW, 20, "Sway", 0.0f, 2.0f, 0.1f,
                () -> PzyConfig.data().sway, v -> PzyConfig.data().sway = v));
        addToggle(left, cy + 24, colW, "screen.pzy_move_horre.right_arm",
                () -> PzyConfig.data().mainArm, v -> PzyConfig.data().mainArm = v);
        addToggle(right, cy + 24, colW, "screen.pzy_move_horre.left_arm",
                () -> PzyConfig.data().offArm, v -> PzyConfig.data().offArm = v);
        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.pzy_move_horre.reset_all"), button -> {
            PzyConfig.resetAll();
            clearChildren();
            init();
        }).dimensions(left, cy + 48, colW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.pzy_move_horre.close"),
                button -> close()).dimensions(right, cy + 48, colW, 20).build());
    }

    private void initPose(int cy, boolean item) {
        int left = panelX + 8;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), button -> {
            kind = kind.next(-1);
            clearChildren();
            init();
        }).dimensions(left, cy, 20, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(kind.label()), button -> {
            kind = kind.next(1);
            clearChildren();
            init();
        }).dimensions(left + 22, cy, 120, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), button -> {
            kind = kind.next(1);
            clearChildren();
            init();
        }).dimensions(left + 144, cy, 20, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.pzy_move_horre.reset_kind"), button -> {
            PzyConfig.resetKind(kind);
            clearChildren();
            init();
        }).dimensions(left + 168, cy, panelW - 16 - 168, 20).build());

        float[] pose = PzyConfig.pose(item, kind);
        String[] names = {"X", "Y", "Z", "Rot X", "Rot Y", "Rot Z"};
        int colW = (panelW - 20) / 2;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 2; col++) {
                int idx = col * 3 + row;
                boolean rot = col == 1;
                float range = rot ? 180.0f : 16.0f;
                float step = rot ? 1.0f : 0.25f;
                addSliderRow(left + col * (colW + 4), cy + 26 + row * 24, colW, names[idx], -range, range, step,
                        () -> pose[idx], v -> pose[idx] = v);
            }
        }
        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.pzy_move_horre.close"),
                button -> close()).dimensions(left, cy + 26 + 3 * 24 + 2, panelW - 16, 18).build());
    }

    /** [-] slider [+] row. */
    private void addSliderRow(int x, int y, int w, String label, float min, float max, float step,
                              Supplier<Float> getter, Consumer<Float> setter) {
        PzySlider slider = new PzySlider(x + 18, y, w - 36, 20, label, min, max, step, getter, setter);
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> slider.nudge(-step))
                .dimensions(x, y, 16, 20).build());
        addDrawableChild(slider);
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> slider.nudge(step))
                .dimensions(x + w - 16, y, 16, 20).build());
    }

    private void addToggle(int x, int y, int w, String key, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(toggleText(key, getter.get()), button -> {
            boolean next = !getter.get();
            setter.accept(next);
            button.setMessage(toggleText(key, next));
            PzyConfig.save();
        }).dimensions(x, y, w, 20).build());
    }

    private static Text toggleText(String key, boolean on) {
        return Text.translatable("screen.pzy_move_horre.toggle", Text.translatable(key),
                Text.translatable(on ? "screen.pzy_move_horre.on" : "screen.pzy_move_horre.off"));
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // No dim or blur: the hands stay visible behind the panel.
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xE60E0E14);
        context.fill(panelX, panelY, panelX + panelW, panelY + 2, 0xFF7A4DFF);
        super.render(context, mouseX, mouseY, delta);
        if (tab == Tab.ABOUT) {
            int cx = width / 2;
            int y = panelY + 32;
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("PZY MOVE HORRE"), cx, y, 0xFFFFFFFF);
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("(c) PZY. All rights reserved."), cx, y + 12, 0xFFC9B8FF);
            context.drawCenteredTextWithShadow(textRenderer, Text.translatable("screen.pzy_move_horre.about_1"), cx, y + 24, 0xFFA0A0B0);
            context.drawCenteredTextWithShadow(textRenderer, Text.translatable("screen.pzy_move_horre.about_2"), cx, y + 36, 0xFFA0A0B0);
        }
    }

    @Override
    public void close() {
        PzyConfig.save();
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }

    /** Slider with real units and step snapping; saves when released. */
    private static final class PzySlider extends SliderWidget {
        private final String label;
        private final float min, max, step;
        private final Supplier<Float> getter;
        private final Consumer<Float> setter;

        PzySlider(int x, int y, int w, int h, String label, float min, float max, float step,
                  Supplier<Float> getter, Consumer<Float> setter) {
            super(x, y, w, h, Text.empty(), (getter.get() - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.step = step;
            this.getter = getter;
            this.setter = setter;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + Math.round(getter.get() * 100.0f) / 100.0f));
        }

        @Override
        protected void applyValue() {
            float v = min + (float) value * (max - min);
            v = Math.round(v / step) * step;
            setter.accept(Math.max(min, Math.min(max, v)));
        }

        void nudge(float delta) {
            float v = Math.max(min, Math.min(max, getter.get() + delta));
            setter.accept(v);
            value = (v - min) / (max - min);
            updateMessage();
            PzyConfig.save();
        }

        @Override
        public void onRelease(double mouseX, double mouseY) {
            super.onRelease(mouseX, mouseY);
            PzyConfig.save();
        }
    }
}
