# วิธี Build ด้วย GitHub จากมือถือ

1. อัปโหลด `PZY_MOVE_HORRE_<เวอร์ชัน>_Source.zip` ไว้ที่ Root ของ Repository
2. อัปโหลด `build.yml` ไว้ที่ `.github/workflows/build.yml` (ครั้งเดียว ใช้ซิปเวอร์ชันล่าสุดให้อัตโนมัติ)
3. Commit แล้วเปิดแท็บ Actions รอจนเขียว แล้วโหลด Artifact ชื่อ `PZY-MOVE-HORRE-<เวอร์ชัน>-Fabric-1.21.1`
4. แตกซิปจะได้ไฟล์ `.jar` เอาไปใส่โฟลเดอร์ mods (ลบ jar PZY เวอร์ชันเก่าออกก่อน)
