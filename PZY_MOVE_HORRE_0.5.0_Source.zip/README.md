# PZY MOVE HORRE 0.5.0

First-person arm + animation system for Minecraft Java 1.21.1, Fabric, Java 21. Client side only.
(c) PZY. All rights reserved. See PZY_LICENSE.txt.

## v0.5.0 - new core
PZY draws the hands completely by itself (vanilla first-person drawing is replaced):
- Both arms always visible (player skin, slim/wide, sleeves)
- Item and arm have separate transforms per item kind (Empty, Sword, Axe, Pickaxe, Shovel, Hoe, Block, Bow, Crossbow, Shield, Trident, Food, Other)
- Settings (key `H` or Mod Menu): tabs Main / Arm / Item / About, sliders for X Y Z (pixels) and rotation (degrees), live preview
- PZY handles equip (hand-in/out), sway, swing arc and eating itself
- Maps and spyglass fall back to vanilla

Config: `config/pzy_move_horre.json`.

## Roadmap
1. (this version) core hands + settings
2. animation engine: Punchy-style bones (right_arm, left_arm, itemgrip_right, itemgrip_left), seconds timeline, resource-pack clips + per-type selection
3. PZY base clips, then new animations

## Build
JDK 21 + Gradle 8.14.3: `gradle --no-daemon clean build` -> `build/libs/pzy_move_horre-0.5.0.jar`
